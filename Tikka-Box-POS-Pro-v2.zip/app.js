const KEY="tikkaBoxPOSProV2";
const TAX_RATE=.06;
const seed={
 menu:[
  ["Butter Chicken","Chicken",12.99],["Chicken Tikka Masala","Chicken",12.99],["Chicken Curry","Chicken",12.99],["Chili Chicken","Chicken",12.99],["Afghani Creamy Chicken","Chicken",12.99],["Mutter Paneer","Vegetarian",10.99],["Shahi Paneer","Vegetarian",10.99],["Chana Masala","Vegetarian",9.99],["Veg Biryani","Vegetarian",9.99],["Samosa","Sides",2.50],["Paneer Pakoda","Sides",6.99],["Mango Lassi","Drinks",3.99],["Jeera Water","Drinks",2.99],["Combo Plate","Combo",12.99]
 ].map((x,i)=>({id:"m"+i,name:x[0],category:x[1],price:x[2],cost:Math.round(x[2]*.35*100)/100,active:true})),
 inventory:[
  {id:"i1",name:"Chicken (lb)",qty:50,unit:"lb",cost:3.20,reorder:10},
  {id:"i2",name:"Basmati Rice (lb)",qty:50,unit:"lb",cost:1.20,reorder:10},
  {id:"i3",name:"Paneer (lb)",qty:15,unit:"lb",cost:4.50,reorder:5},
  {id:"i4",name:"Mango Lassi",qty:24,unit:"each",cost:1.10,reorder:6},
  {id:"i5",name:"Samosa",qty:30,unit:"each",cost:.65,reorder:8}
 ],
 sales:[],expenses:[],settings:{tax:true}
};
let db=JSON.parse(localStorage.getItem(KEY)||"null")||seed;
let cart=[];

function save(){localStorage.setItem(KEY,JSON.stringify(db))}
function money(n){return "$"+Number(n||0).toFixed(2)}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function cats(){return [...new Set(db.menu.map(x=>x.category))].sort()}
function renderCats(){catFilter.innerHTML='<option value="">All categories</option>'+cats().map(c=>`<option>${esc(c)}</option>`).join("")}
function renderMenu(){
 const q=search.value.toLowerCase(), c=catFilter.value;
 menuGrid.innerHTML=db.menu.filter(x=>x.active&&(!c||x.category===c)&&x.name.toLowerCase().includes(q)).map(x=>`
 <button class="menu-card" onclick="addToCart('${x.id}')"><div class="category">${esc(x.category)}</div><h3>${esc(x.name)}</h3><div class="price">${money(x.price)}</div></button>`).join("");
}
function addToCart(id){const m=db.menu.find(x=>x.id===id);let r=cart.find(x=>x.id===id);if(r)r.qty++;else cart.push({id,qty:1});renderCart()}
function renderCart(){
 let sub=0;
 cartItems.innerHTML=cart.map(r=>{let m=db.menu.find(x=>x.id===r.id),v=m.price*r.qty;sub+=v;return `<div class="cartrow"><div><b>${esc(m.name)}</b><div class="muted">${money(m.price)} × ${r.qty}</div></div><div class="qty"><button onclick="changeQty('${r.id}',-1)">−</button> ${r.qty} <button onclick="changeQty('${r.id}',1)">+</button></div></div>`}).join("")||'<div class="muted">No items yet.</div>';
 const d=Math.min(Math.max(Number(discount.value)||0,0),sub), tax=db.settings.tax?(sub-d)*TAX_RATE:0, total=sub-d+tax;
 subtotal.textContent=money(sub);tax.textContent=money(tax);document.getElementById("total").textContent=money(total);
}
function changeQty(id,n){let r=cart.find(x=>x.id===id);if(!r)return;r.qty+=n;if(r.qty<=0)cart=cart.filter(x=>x.id!==id);renderCart()}
function checkout(method){
 if(!cart.length){orderMsg.textContent="Add an item first.";return}
 let sub=cart.reduce((a,r)=>a+db.menu.find(x=>x.id===r.id).price*r.qty,0);
 let d=Math.min(Math.max(Number(discount.value)||0,0),sub), tax=db.settings.tax?(sub-d)*TAX_RATE:0,total=sub-d+tax;
 const cost=cart.reduce((a,r)=>a+db.menu.find(x=>x.id===r.id).cost*r.qty,0);
 db.sales.unshift({id:Date.now(),date:new Date().toISOString(),items:cart.map(r=>({...r})),subtotal:sub,discount:d,tax,total,method,cost,profit:total-cost});
 db.sales=db.sales.slice(0,1000); save(); cart=[]; discount.value=0; renderCart(); renderReports(); orderMsg.textContent=`${method} sale recorded — ${money(total)}`;
 setTimeout(()=>orderMsg.textContent="",2500);
}
function renderMenuAdmin(){
 menuAdmin.innerHTML=db.menu.map(m=>`<div class="adminrow"><div><b>${esc(m.name)}</b><div class="muted">${esc(m.category)} · Sell ${money(m.price)} · Cost ${money(m.cost)} ${m.active?"":"· HIDDEN"}</div></div><div class="adminactions"><button class="btn" onclick="editMenu('${m.id}')">Edit</button><button class="btn" onclick="toggleMenu('${m.id}')">${m.active?"Hide":"Show"}</button></div></div>`).join("");
}
function editMenu(id){
 const m=db.menu.find(x=>x.id===id)||{id:"m"+Date.now(),name:"",category:"Chicken",price:0,cost:0,active:true};
 openModal(id?"Edit Menu Item":"Add Menu Item",`
 <div class="formgrid"><label>Name<input name="name" value="${esc(m.name)}" required></label><div class="row"><label>Category<input name="category" value="${esc(m.category)}" required></label><label>Price<input name="price" type="number" step=".01" value="${m.price}" required></label></div><label>Food Cost<input name="cost" type="number" step=".01" value="${m.cost}" required></label><div class="formactions"><button class="btn primary">Save Item</button></div></div>`, data=>{
  Object.assign(m,{name:data.name,category:data.category,price:Number(data.price),cost:Number(data.cost),active:true});if(!id)db.menu.push(m);save();renderAll();
 });
}
function toggleMenu(id){let m=db.menu.find(x=>x.id===id);m.active=!m.active;save();renderAll()}
function renderInventory(){
 inventoryList.innerHTML=db.inventory.map(i=>`<div class="invrow"><div><b>${esc(i.name)}</b><div class="muted">${i.qty} ${esc(i.unit)} · Cost ${money(i.cost)} · Reorder at ${i.reorder}</div></div><div>${i.qty<=i.reorder?'<b class="danger">LOW STOCK</b> ':''}<button class="btn" onclick="editInv('${i.id}')">Edit</button></div></div>`).join("");
}
function editInv(id){
 const i=db.inventory.find(x=>x.id===id)||{id:"i"+Date.now(),name:"",qty:0,unit:"each",cost:0,reorder:5};
 openModal(id?"Edit Inventory":"Add Purchase/Stock",`<div class="formgrid"><label>Item<input name="name" value="${esc(i.name)}" required></label><div class="row"><label>Quantity<input name="qty" type="number" step=".01" value="${i.qty}"></label><label>Unit<input name="unit" value="${esc(i.unit)}"></label></div><div class="row"><label>Unit Cost<input name="cost" type="number" step=".01" value="${i.cost}"></label><label>Reorder Level<input name="reorder" type="number" step=".01" value="${i.reorder}"></label></div><div class="formactions"><button class="btn primary">Save</button></div></div>`,d=>{Object.assign(i,{name:d.name,qty:Number(d.qty),unit:d.unit,cost:Number(d.cost),reorder:Number(d.reorder)});if(!id)db.inventory.push(i);save();renderAll()})
}
function addPurchase(){editInv(null)}
function addExpense(){
 openModal("Add Expense",`<div class="formgrid"><label>Description<input name="desc" required></label><label>Amount<input name="amount" type="number" step=".01" required></label><label>Category<input name="category" value="Supplies"></label><div class="formactions"><button class="btn primary">Save Expense</button></div></div>`,d=>{db.expenses.unshift({id:Date.now(),date:new Date().toISOString(),desc:d.desc,amount:Number(d.amount),category:d.category});save();renderReports()})
}
function renderReports(){
 const today=new Date().toISOString().slice(0,10), ts=db.sales.filter(s=>s.date.slice(0,10)===today), sales=ts.reduce((a,s)=>a+s.total,0), profit=ts.reduce((a,s)=>a+s.profit,0), exp=db.expenses.filter(e=>e.date.slice(0,10)===today).reduce((a,e)=>a+e.amount,0);
 stats.innerHTML=[["Sales",money(sales)],["Orders",ts.length],["Gross Profit",money(profit)],["Expenses",money(exp)],["Net",money(profit-exp)]].map(x=>`<div class="stat"><span class="muted">${x[0]}</span><b>${x[1]}</b></div>`).join("");
 let counts={};db.sales.forEach(s=>s.items.forEach(r=>{let m=db.menu.find(x=>x.id===r.id);if(m)counts[m.name]=(counts[m.name]||0)+r.qty}));best.innerHTML=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,8).map(x=>`<div class="listitem"><b>${esc(x[0])}</b><span class="muted"> × ${x[1]}</span></div>`).join("")||'<div class="muted">No sales yet.</div>';
 salesEl=document.getElementById("sales");salesEl.innerHTML=db.sales.slice(0,8).map(s=>`<div class="listitem"><b>${money(s.total)}</b> · ${s.method}<div class="muted">${new Date(s.date).toLocaleString()}</div></div>`).join("")||'<div class="muted">No sales yet.</div>';
 expenses.innerHTML=db.expenses.slice(0,10).map(e=>`<div class="listitem"><b>${esc(e.desc)}</b> · ${money(e.amount)} <span class="muted">${esc(e.category)}</span></div>`).join("")||'<div class="muted">No expenses yet.</div>';
}
function openModal(title,html,onSubmit){modalTitle.textContent=title;modalForm.innerHTML=html;modal.classList.remove("hidden");modalForm.onsubmit=e=>{e.preventDefault();let d=Object.fromEntries(new FormData(modalForm).entries());closeModal();onSubmit(d)}}
function closeModal(){modal.classList.add("hidden");modalForm.innerHTML=""}
function renderAll(){renderCats();renderMenu();renderCart();renderMenuAdmin();renderInventory();renderReports();taxToggle.textContent=db.settings.tax?"ON":"OFF";taxToggle.className="pill "+(db.settings.tax?"on":"off")}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.getElementById(b.dataset.tab).classList.add("active")});
search.oninput=renderMenu;catFilter.onchange=renderMenu;discount.oninput=renderCart;
document.querySelectorAll("[data-pay]").forEach(b=>b.onclick=()=>checkout(b.dataset.pay));
clearOrder.onclick=()=>{cart=[];discount.value=0;renderCart()};taxToggle.onclick=()=>{db.settings.tax=!db.settings.tax;save();renderCart();renderAll()};
addItem.onclick=()=>editMenu(null);addStock.onclick=addPurchase;addExpense.onclick=addExpense;closeModal.onclick=closeModal;
backup.onclick=()=>{let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(db,null,2)],{type:"application/json"}));a.download="tikka-box-backup.json";a.click()};
restore.onclick=()=>restoreFile.click();restoreFile.onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{db=JSON.parse(r.result);save();renderAll();alert("Backup restored.")}catch{alert("Invalid backup file.")}};r.readAsText(f)};
document.getElementById("ownerBtn").onclick=()=>document.querySelector('[data-tab="reports"]').click();
renderAll();
