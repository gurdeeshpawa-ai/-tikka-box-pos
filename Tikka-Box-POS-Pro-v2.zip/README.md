# Tikka Box POS Pro v2

A self-contained iPhone/iPad-friendly POS for Tikka Box.

Included:
- Fast order screen
- Menu editor: add/edit/hide items
- Categories including Chicken, Vegetarian, Sides, Drinks and Combo
- Combo Plate starter item
- 6% tax toggle
- Manual dollar discount
- Cash/Card checkout
- Inventory and stock/purchase entry
- Low-stock alerts
- Food cost and gross profit per sale
- Expense tracking
- Owner dashboard: sales, orders, gross profit, expenses and net
- Best sellers and recent sales
- JSON backup/restore
- Data stored locally in the browser

Important:
This version is a local-first POS. It does not directly process card payments, print to a kitchen printer, or sync data to a cloud database. The Card button records a card payment after the payment is completed on your existing terminal.
